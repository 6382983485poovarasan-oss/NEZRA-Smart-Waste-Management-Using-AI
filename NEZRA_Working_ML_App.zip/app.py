import os
import streamlit as st
from PIL import Image

st.set_page_config(page_title="NEZRA – Smart Waste", page_icon="♻️", layout="wide")

CLASSES = ["plastic", "paper", "cardboard", "glass", "metal", "organic", "other"]

RECOMMENDATIONS = {
    "plastic": ("Recycle", "Clean and separate accepted plastic. Reuse containers when safe, then send them to an appropriate plastic recycling service."),
    "paper": ("Recycle / Reuse", "Reuse clean paper where possible or place it in an accepted paper-recycling stream."),
    "cardboard": ("Recycle", "Flatten clean cardboard and send it to a paper/cardboard recycling service."),
    "glass": ("Recycle", "Handle glass carefully and use an appropriate glass-recycling collection point."),
    "metal": ("Recycle", "Separate metal items and send them to a metal collection or recycling centre."),
    "organic": ("Compost", "Suitable food and garden waste can often be composted or sent to an organic-waste collection service."),
    "other": ("Check locally", "The item could not be confidently assigned to a supported category. Follow your local waste-disposal guidance."),
}

RECYCLERS = [
    {"name": "Plastic Recycler", "accepted": ["plastic"], "service": "Plastic collection / recycling"},
    {"name": "Paper & Cardboard Recycler", "accepted": ["paper", "cardboard"], "service": "Paper and cardboard recycling"},
    {"name": "Glass Recycling Centre", "accepted": ["glass"], "service": "Glass collection / recycling"},
    {"name": "Metal Collection Centre", "accepted": ["metal"], "service": "Metal recovery / recycling"},
    {"name": "Organic Waste Centre", "accepted": ["organic"], "service": "Composting / organic collection"},
]

@st.cache_resource(show_spinner="Loading the vision model for NEZRA…")
def load_vision_model():
    """Load a general-purpose zero-shot image model.

    This is a genuine ML model, but it is not a waste-specific model. The UI
    therefore reports it as a general vision model and does not claim a
    validated waste-classification accuracy.
    """
    try:
        from transformers import pipeline
        classifier = pipeline(
            "zero-shot-image-classification",
            model="openai/clip-vit-base-patch32",
        )
        return classifier, None
    except Exception as exc:
        return None, str(exc)


def classify_image(image):
    classifier, error = load_vision_model()
    if classifier is None:
        return "other", 0.0, "fallback", error

    prompts = [
        "a photo of plastic waste",
        "a photo of paper waste",
        "a photo of cardboard waste",
        "a photo of glass waste",
        "a photo of metal waste",
        "a photo of organic food or garden waste",
        "a photo of other miscellaneous waste",
    ]
    results = classifier(image.convert("RGB"), candidate_labels=prompts)
    best = results[0]
    mapping = {
        prompts[0]: "plastic", prompts[1]: "paper", prompts[2]: "cardboard",
        prompts[3]: "glass", prompts[4]: "metal", prompts[5]: "organic",
        prompts[6]: "other",
    }
    label = mapping.get(best["label"], "other")
    return label, float(best["score"]), "CLIP zero-shot", None


def answer_voice_query(q):
    q = q.lower()
    for item in CLASSES:
        if item in q:
            action, text = RECOMMENDATIONS[item]
            return f"{item.title()}: {action}. {text}"
    return "Tell me the waste type, for example plastic, paper, glass, metal, or organic, and I will give you a recommendation."

st.title("♻️ NEZRA")
st.caption("Network for Exchange, Zero Waste, Reuse & Recycling Assistant")

with st.sidebar:
    st.header("NEZRA")
    page = st.radio("Navigation", ["🏠 Home", "📷 Smart Scan", "♻️ Recommendation", "🚚 Recycler Network", "🎙️ Voice Assistant", "ℹ️ About"])
    st.divider()
    st.caption("Working ML demo: CLIP zero-shot image classification")

if page == "🏠 Home":
    st.subheader("Smart Waste Management Dashboard")
    a, b, c = st.columns(3)
    a.metric("Image analysis", "Enabled")
    b.metric("Waste categories", "7")
    c.metric("Workflow", "Scan → Act")
    st.markdown("""
    ### How NEZRA works
    1. Upload a waste image or take a camera photo.
    2. The image is analysed by a vision model.
    3. NEZRA maps the result to a supported waste category.
    4. A disposal/recycling recommendation is shown.
    5. Matching recycler/collection information is displayed.
    """)
    st.info("The included model is a general-purpose CLIP vision model used in zero-shot mode. It is a working ML demonstration, not a validated waste-specific classifier.")

elif page == "📷 Smart Scan":
    st.subheader("Smart Scan")
    source = st.radio("Image source", ["Upload image", "Camera"], horizontal=True)
    file = st.file_uploader("Upload a waste image", type=["jpg", "jpeg", "png"]) if source == "Upload image" else st.camera_input("Take a picture")
    if file:
        image = Image.open(file).convert("RGB")
        st.image(image, caption="Waste image", use_container_width=True)
        if st.button("🔎 Analyse Waste", type="primary", use_container_width=True):
            with st.spinner("NEZRA is analysing the image…"):
                label, confidence, engine, error = classify_image(image)
            st.session_state["waste_type"] = label
            st.session_state["confidence"] = confidence
            st.session_state["engine"] = engine
            if engine == "fallback":
                st.error("The ML model could not be loaded in this environment.")
                st.caption(error or "Unknown model-loading error")
            else:
                st.success(f"Detected category: **{label.title()}**")
                st.metric("Model score", f"{confidence * 100:.1f}%")
                st.caption(f"Inference engine: {engine}. The score is model confidence, not a validated accuracy percentage.")
            action, advice = RECOMMENDATIONS[label]
            st.subheader("Recommended action")
            st.write(f"**{action}**")
            st.write(advice)

elif page == "♻️ Recommendation":
    st.subheader("Disposal & Recycling Recommendation")
    waste = st.session_state.get("waste_type")
    if not waste:
        st.info("Scan a waste image first.")
    else:
        action, advice = RECOMMENDATIONS[waste]
        st.write(f"### Detected: {waste.title()}")
        st.write(f"**Action:** {action}")
        st.write(advice)

elif page == "🚚 Recycler Network":
    st.subheader("Recycler Network")
    waste = st.session_state.get("waste_type", "plastic")
    selected = st.selectbox("Waste category", CLASSES, index=CLASSES.index(waste))
    matches = [r for r in RECYCLERS if selected in r["accepted"]]
    if matches:
        for r in matches:
            with st.container(border=True):
                st.write(f"### {r['name']}")
                st.write(r["service"])
                st.button("Connect / Contact", key=r["name"])
    else:
        st.info("No recycler entry is configured for this category yet.")

elif page == "🎙️ Voice Assistant":
    st.subheader("NEZRA Assistant")
    st.write("Type a question and NEZRA will provide a waste-management response.")
    q = st.text_input("Ask NEZRA", placeholder="What should I do with plastic?")
    if st.button("Ask NEZRA", type="primary"):
        st.success(answer_voice_query(q))

elif page == "ℹ️ About":
    st.subheader("About NEZRA")
    st.write("NEZRA combines image analysis, waste classification, recommendations, recycler matching and user interaction in one smart waste-management application.")
    st.markdown("**ML:** CLIP zero-shot image classification")
    st.markdown("**UI:** Streamlit")
    st.markdown("**Supported categories:** Plastic, Paper, Cardboard, Glass, Metal, Organic, Other")
    st.warning("For a final academic submission, a waste-specific trained dataset/model should be evaluated separately with accuracy, precision, recall, F1-score and a confusion matrix.")
