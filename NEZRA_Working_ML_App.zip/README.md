# NEZRA – Working Smart Waste Management App

NEZRA is a Streamlit web application for image-based waste analysis, recommendations, recycler matching and a simple assistant.

## ML model
This version uses OpenAI CLIP (`openai/clip-vit-base-patch32`) through Hugging Face Transformers in **zero-shot image classification** mode. It is a real ML vision model and can analyse uploaded/camera images without a separate training dataset.

Important: CLIP is a general-purpose vision-language model, not a waste-specific model. Its score is not a validated accuracy percentage. For an academic final model, replace it with a waste-specific trained CNN/transfer-learning model and report accuracy, precision, recall, F1 and confusion matrix.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

The first ML prediction downloads the model from Hugging Face, so internet access is required on first run.

## Deploy
1. Create a public GitHub repository.
2. Upload `app.py`, `requirements.txt`, and `README.md`.
3. Open Streamlit Community Cloud.
4. Choose the repository, branch `main`, and file `app.py`.
5. Deploy.

## Features
- Image upload
- Camera capture
- ML image classification
- Recommendation engine
- Recycler matching
- Assistant page
- Mobile-friendly Streamlit interface
